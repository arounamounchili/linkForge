# Xacro (XML Macros)

**Xacro is an XML macro language**

With `xacro`, you can construct shorter and more readable XML files by using macros that expand to larger XML expressions.
Recent documentation can be found in the [wiki](https://github.com/ros/xacro/wiki). For older releases, have a look at the [ROS wiki](http://wiki.ros.org/xacro).
